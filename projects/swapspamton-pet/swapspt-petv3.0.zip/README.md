使用说明

左键点击桌宠对话，右键点击显示菜单和退出，进入控制面板和商店界面和便签界面同样右键点击桌宠退出。可切换中英文，如有不适可暂停、隐藏桌宠和暂停自动对话，会暂停时间间隔性对话和点击桌宠时对话。可自行调节桌宠音量甚至关闭声音，固定时间会有喝水吃饭和睡觉提示，桌宠自带开机自启功能，如不需要可以自行去系统中关闭，或者是打开。右键菜单点击便签可以记录日常灵感或重要事件，点击小游戏可自行游玩多种已配置完毕的游戏。按下ctrl鼠标滚轮在桌宠上滑动可以调整桌宠大小。

下载链接：https://github.com/ternatapinellia/swapspamton-desktoppet/releases/tag/v3.0

备注：v3.0 为当前发布版本，后续会继续调整词条和桌宠图片等。

可能存在的问题：

1.英文是机翻，部分不准确，小游戏的农场功能并没有翻译。

2.商店使用的是日文api然后获得的结果再翻译成中文，所以初始加载比较缓慢，可能需要半分钟到一分钟。

## User Instructions

* **Left-click** the desktop pet to interact and talk with it.
* **Right-click** the desktop pet to open the menu or exit.
* The same right-click menu is available when entering the **Control Panel**, **Shop**, or **Notepad** interfaces, where you can also exit the desktop pet.
* The interface supports **Chinese and English**.
* If you feel uncomfortable with the desktop pet, you can **pause or hide it**, or disable **automatic conversations**. This will stop both periodic conversations and conversations triggered by clicking the desktop pet.
* You can adjust the desktop pet's **volume** or turn the sound off completely.
* The desktop pet provides reminders at fixed times for **drinking water, eating, and sleeping**.
* The desktop pet supports **automatic startup with Windows**. You can enable or disable this feature in the system settings as needed.
* Select **Notepad** from the right-click menu to record daily inspirations, important events, or other notes.
* Select **Mini Games** from the right-click menu to play a variety of pre-configured games.
* Hold **Ctrl** and scroll the mouse wheel while hovering over the desktop pet to adjust its size.

## Download

[Download DeskPet V3.0](https://github.com/ternatapinellia/swapspamton-desktoppet/releases/tag/v3.0)

## Notes

**v3.0** is the current release of the desktop pet. Future updates will continue to refine dialogue entries and desktop pet images.

## Known Issues

1. The English translation is currently **machine-translated**, so some translations may be inaccurate. The **farmland feature in the mini games** has not been translated into English yet.
2. The Shop uses a **Japanese API** to retrieve its results and then translates them into Chinese. Therefore, the initial loading process may be relatively slow and can take approximately **30 seconds to 1 minute**.

——

v3.0 update

1. Fixed Windows autostart registration failures and out-of-sync menu/tray checkmarks.

2. Added memory for the desktop pet position and size; both are restored on the next launch.

3. Improved shutdown: save the pet state and stop background tasks to reduce freezes or crashes.

——

v2.11更新

修复了星露谷小游戏中，等级与田地信息过长时被裁掉、无法滚动查看的问题；商店页面也补上了滚动条

——

v2.1更新

调整了面板位置，修复了商品页面导致桌宠整体卡顿的bug

——

v2.0更新

1.修复了面板会跟随桌宠乱动的bug，固定在了桌宠附近固定位置

——

v1.2更新

1.增加了桌宠静止和说话动画形态

2.扩充了小游戏成语接龙的词库

——

v1.21更新

1.修复了成语接龙和deal游戏的bug

——

v1.1更新

1.修复了deal游戏的bug
