$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$dll = Join-Path $base 'CompetInputFix.dll'
$exe = Join-Path $base 'Compet.exe'

if (!(Test-Path -LiteralPath $dll)) { throw "Missing CompetInputFix.dll: $dll" }
if (!(Test-Path -LiteralPath $exe)) { throw "Missing Compet.exe. Put this folder next to Compet.exe." }

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class CompetInjector {
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr VirtualAllocEx(IntPtr h, IntPtr a, UIntPtr size, uint type, uint protect);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool WriteProcessMemory(IntPtr h, IntPtr a, byte[] data, UIntPtr size, out UIntPtr written);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr GetModuleHandle(string name);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr GetProcAddress(IntPtr h, string name);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr CreateRemoteThread(IntPtr h, IntPtr attr, UIntPtr stack, IntPtr start, IntPtr param, uint flags, out uint tid);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern uint WaitForSingleObject(IntPtr h, uint ms);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool VirtualFreeEx(IntPtr h, IntPtr a, UIntPtr size, uint type);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool CloseHandle(IntPtr h);
}
"@

$p = Get-Process -Name Compet -ErrorAction SilentlyContinue | Select-Object -First 1
if (!$p) {
    Start-Process -FilePath $exe -WorkingDirectory $base | Out-Null
    Start-Sleep -Seconds 3
    $p = Get-Process -Name Compet -ErrorAction SilentlyContinue | Select-Object -First 1
}
if (!$p) { throw 'Compet.exe did not start.' }

$PROCESS = 0x0438
$MEM_COMMIT_RESERVE = 0x3000
$PAGE_READWRITE = 0x04
$MEM_RELEASE = 0x8000
$h = [CompetInjector]::OpenProcess($PROCESS, $false, [uint32]$p.Id)
if ($h -eq [IntPtr]::Zero) {
    $e = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
    throw "OpenProcess failed. Win32 error: $e. Run this script as Administrator."
}

try {
    $bytes = [Text.Encoding]::Unicode.GetBytes($dll + [char]0)
    $mem = [CompetInjector]::VirtualAllocEx($h, [IntPtr]::Zero, [UIntPtr]::new([uint64]$bytes.Length), $MEM_COMMIT_RESERVE, $PAGE_READWRITE)
    if ($mem -eq [IntPtr]::Zero) { throw 'VirtualAllocEx failed.' }
    try {
        [UIntPtr]$written = [UIntPtr]::Zero
        $ok = [CompetInjector]::WriteProcessMemory($h, $mem, $bytes, [UIntPtr]::new([uint64]$bytes.Length), [ref]$written)
        if (!$ok) { throw 'WriteProcessMemory failed.' }
        $k32 = [CompetInjector]::GetModuleHandle('kernel32.dll')
        $load = [CompetInjector]::GetProcAddress($k32, 'LoadLibraryW')
        if ($load -eq [IntPtr]::Zero) { throw 'LoadLibraryW not found.' }
        [uint32]$tid = 0
        $th = [CompetInjector]::CreateRemoteThread($h, [IntPtr]::Zero, [UIntPtr]::Zero, $load, $mem, 0, [ref]$tid)
        if ($th -eq [IntPtr]::Zero) {
            $e = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
            throw "CreateRemoteThread failed. Win32 error: $e"
        }
        [void][CompetInjector]::WaitForSingleObject($th, 5000)
        [void][CompetInjector]::CloseHandle($th)
    }
    finally {
        [void][CompetInjector]::VirtualFreeEx($h, $mem, [UIntPtr]::Zero, $MEM_RELEASE)
    }
}
finally {
    [void][CompetInjector]::CloseHandle($h)
}

Write-Host 'Compet input fix injected.' -ForegroundColor Green
exit 0
