Option Explicit

Dim shell, app, fso, folder, fixBat, ps1, exePath, cmd, elevated
Set shell = CreateObject("WScript.Shell")
Set app = CreateObject("Shell.Application")
Set fso = CreateObject("Scripting.FileSystemObject")

folder = fso.GetParentFolderName(WScript.ScriptFullName)
exePath = folder & "\Compet.exe"
fixBat = folder & "\start.bat"
ps1 = folder & "\GamepadBridge.ps1"

If Not fso.FileExists(exePath) Then
    MsgBox "Compet.exe not found.", 16, "Compet Xbox"
    WScript.Quit 1
End If

If Not fso.FileExists(fixBat) Then
    MsgBox "start.bat not found.", 16, "Compet Xbox"
    WScript.Quit 1
End If

' Re-launch this VBS as Administrator.
If Not WScript.Arguments.Named.Exists("elevated") Then
    app.ShellExecute "wscript.exe", Chr(34) & WScript.ScriptFullName & Chr(34) & " /elevated", folder, "runas", 1
    WScript.Quit 0
End If

' Start the original Compet input fix. The fix script itself starts Compet if needed.
shell.CurrentDirectory = folder
shell.Run "cmd.exe /c " & Chr(34) & fixBat & Chr(34), 0, False
WScript.Sleep 2500

' Keep the existing gamepad bridge.
If fso.FileExists(ps1) Then
    cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & ps1 & Chr(34)
    shell.Run cmd, 0, False
End If

Set fso = Nothing
Set app = Nothing
Set shell = Nothing
