$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$dll = Join-Path $base 'CompetInputFix.dll'
$exe = Join-Path $base 'Compet.exe'
if (!(Test-Path -LiteralPath $dll)) { throw "找不到 CompetInputFix.dll: $dll" }
if (!(Test-Path -LiteralPath $exe)) { throw "找不到 Compet.exe: $exe" }
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class CompetInjectorV61 {
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr VirtualAllocEx(IntPtr h, IntPtr a, UIntPtr size, uint type, uint protect);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool WriteProcessMemory(IntPtr h, IntPtr a, byte[] data, UIntPtr size, out UIntPtr written);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr GetModuleHandle(string name);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr GetProcAddress(IntPtr h, string name);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr CreateRemoteThread(IntPtr h, IntPtr attr, UIntPtr stack, IntPtr start, IntPtr param, uint flags, out uint tid);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern uint WaitForSingleObject(IntPtr h, uint ms);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool VirtualFreeEx(IntPtr h, IntPtr a, UIntPtr size, uint type);
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool CloseHandle(IntPtr h);
}
"@
$p = Get-Process -Name Compet -ErrorAction SilentlyContinue | Select-Object -First 1
if (!$p) { Start-Process -FilePath $exe -WorkingDirectory $base | Out-Null; Start-Sleep -Seconds 3; $p = Get-Process -Name Compet -ErrorAction SilentlyContinue | Select-Object -First 1 }
if (!$p) { throw 'Compet.exe 未启动。' }
$PROCESS = 0x0438; $MEM_COMMIT_RESERVE = 0x3000; $PAGE_READWRITE = 0x04; $MEM_RELEASE = 0x8000
$h = [CompetInjectorV61]::OpenProcess($PROCESS, $false, [uint32]$p.Id)
if ($h -eq [IntPtr]::Zero) { $e=[Runtime.InteropServices.Marshal]::GetLastWin32Error(); throw "OpenProcess failed: Win32 $e" }
try {
 $bytes=[Text.Encoding]::Unicode.GetBytes($dll+[char]0)
 $mem=[CompetInjectorV61]::VirtualAllocEx($h,[IntPtr]::Zero,[UIntPtr]::new([uint64]$bytes.Length),$MEM_COMMIT_RESERVE,$PAGE_READWRITE)
 if ($mem -eq [IntPtr]::Zero) { throw 'VirtualAllocEx failed.' }
 try {
  [UIntPtr]$written=[UIntPtr]::Zero
  if (![CompetInjectorV61]::WriteProcessMemory($h,$mem,$bytes,[UIntPtr]::new([uint64]$bytes.Length),[ref]$written)) { throw 'WriteProcessMemory failed.' }
  $k32=[CompetInjectorV61]::GetModuleHandle('kernel32.dll'); $load=[CompetInjectorV61]::GetProcAddress($k32,'LoadLibraryW')
  if ($load -eq [IntPtr]::Zero) { throw 'LoadLibraryW not found.' }
  [uint32]$tid=0; $th=[CompetInjectorV61]::CreateRemoteThread($h,[IntPtr]::Zero,[UIntPtr]::Zero,$load,$mem,0,[ref]$tid)
  if ($th -eq [IntPtr]::Zero) { $e=[Runtime.InteropServices.Marshal]::GetLastWin32Error(); throw "CreateRemoteThread failed: Win32 $e" }
  [void][CompetInjectorV61]::WaitForSingleObject($th,5000); [void][CompetInjectorV61]::CloseHandle($th)
 } finally { [void][CompetInjectorV61]::VirtualFreeEx($h,$mem,[UIntPtr]::Zero,$MEM_RELEASE) }
} finally { [void][CompetInjectorV61]::CloseHandle($h) }
Write-Host 'CompetInputFix v6.1 injected.' -ForegroundColor Green
Write-Host "日志文件：$base\CompetInputFix.log"
