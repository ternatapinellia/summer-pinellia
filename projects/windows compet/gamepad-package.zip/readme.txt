gamepad-package.exe解压后文件夹中数十个文件需要放置到和桌宠软件exe同目录下。使用的时候请首先按下gamepadsetting.bat来配置手柄按键，目前按键键位按照xbox手柄键位书写。而后按下start.vbs进行启动。

ggdw为swapspamton的皮肤包。addispam为ads时期spamton的皮肤包，dnt为defernull tenna的皮肤包，解压后即可使用，如软件支持zip导入，也可直接导入。

config.json中可以查看各个桌宠的按键配置规范，f18-f24和上下左右按键等为原本配置的手柄键位。

