package main

import (
	"bytes"
	"crypto/ed25519"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type result struct {
	status int
	err    error
	ms     int64
}

func keyOf(secret string) (ed25519.PublicKey, ed25519.PrivateKey) {
	seed := secret
	for len(seed) < ed25519.SeedSize {
		seed = strings.Repeat(seed, 2)
	}
	pub, priv, err := ed25519.GenerateKey(strings.NewReader(seed[:ed25519.SeedSize]))
	if err != nil {
		panic(err)
	}
	return pub, priv
}

func sign(priv ed25519.PrivateKey, ts string, body []byte) string {
	return hex.EncodeToString(ed25519.Sign(priv, append([]byte(ts), body...)))
}

func main() {
	secret := flag.String("secret", "", "app secret")
	url := flag.String("url", "", "callback url")
	total := flag.Int("n", 500, "total events")
	conc := flag.Int("c", 10, "concurrency")
	dupRatio := flag.Int("dup", 20, "percent of events that are duplicated (0-100)")
	flag.Parse()
	if *secret == "" || *url == "" {
		fmt.Println("usage: loadtest -secret <s> -url <u> [-n 500] [-c 10] [-dup 20]")
		os.Exit(1)
	}

	base := strings.TrimSuffix(*url, "/qq/callback")
	_, priv := keyOf(*secret)
	client := &http.Client{Timeout: 30 * time.Second}

	// 1) op=13 validation first
	ts := fmt.Sprintf("%d", time.Now().Unix())
	valBody := fmt.Sprintf("{\"op\":13,\"d\":{\"plain_token\":\"lt%s\",\"event_ts\":\"%s\"}}", ts[6:], ts)
	req, _ := http.NewRequest("POST", *url, bytes.NewReader([]byte(valBody)))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-Signature-Timestamp", ts)
	req.Header.Set("X-Signature-Ed25519", sign(priv, ts, []byte(valBody)))
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("op=13 request failed:", err)
		os.Exit(1)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	ok13 := resp.StatusCode == 200 && strings.Contains(string(body), "signature")
	fmt.Printf("op=13 validation: status=%d ok=%v\n", resp.StatusCode, ok13)
	if !ok13 {
		fmt.Println("ABORT: op=13 failed, gateway not usable")
		os.Exit(1)
	}

	type job struct {
		id  string
		dup bool
	}
	jobs := make([]job, 0, *total)
	dupCount := *total * *dupRatio / 100
	for i := 0; i < *total; i++ {
		isDup := i < dupCount
		jobs = append(jobs, job{id: fmt.Sprintf("LT_%d_%d", time.Now().UnixNano(), i), dup: isDup})
	}
	// duplicated events use the first dupCount ids so they repeat
	for i := 0; i < dupCount; i++ {
		jobs = append(jobs, job{id: jobs[i].id, dup: true})
	}

	sem := make(chan struct{}, *conc)
	var wg sync.WaitGroup
	results := make([]result, len(jobs))
	var sent int64

	start := time.Now()
	for i, j := range jobs {
		wg.Add(1)
		sem <- struct{}{}
		go func(idx int, jb job) {
			defer wg.Done()
			defer func() { <-sem }()
			evBody := fmt.Sprintf("{\"op\":0,\"id\":\"%s\",\"t\":\"GROUP_AT_MESSAGE_CREATE\",\"d\":{\"content\":\"loadtest\"}}", jb.id)
			ts := fmt.Sprintf("%d", time.Now().Unix())
			r, _ := http.NewRequest("POST", *url, bytes.NewReader([]byte(evBody)))
			r.Header.Set("Content-Type", "application/json")
			r.Header.Set("X-Signature-Timestamp", ts)
			r.Header.Set("X-Signature-Ed25519", sign(priv, ts, []byte(evBody)))
			t0 := time.Now()
			rsp, err := client.Do(r)
			el := time.Since(t0).Milliseconds()
			atomic.AddInt64(&sent, 1)
			if err != nil {
				results[idx] = result{status: -1, err: err, ms: el}
				return
			}
			io.Copy(io.Discard, rsp.Body)
			rsp.Body.Close()
			results[idx] = result{status: rsp.StatusCode, ms: el}
		}(i, j)
	}
	wg.Wait()
	elapsed := time.Since(start)

	var ok, bad int
	var latency []int64
	for _, r := range results {
		if r.status == 200 {
			ok++
			latency = append(latency, r.ms)
		} else {
			bad++
		}
	}
	sort.Slice(latency, func(a, b int) bool { return latency[a] < latency[b] })
	pct := func(p float64) int64 {
		if len(latency) == 0 {
			return 0
		}
		idx := int(float64(len(latency)-1) * p)
		return latency[idx]
	}

	fmt.Printf("\n--- event delivery ---\n")
	fmt.Printf("sent        : %d  (unique=%d duplicated=%d)\n", len(jobs), *total, dupCount)
	fmt.Printf("http 200    : %d\n", ok)
	fmt.Printf("http failed : %d\n", bad)
	fmt.Printf("error rate  : %.2f%%\n", float64(bad)*100/float64(len(jobs)))
	fmt.Printf("elapsed     : %s\n", elapsed.Round(time.Millisecond))
	fmt.Printf("throughput  : %.1f req/s\n", float64(len(jobs))/elapsed.Seconds())
	fmt.Printf("latency p50 : %d ms\n", pct(0.50))
	fmt.Printf("latency p90 : %d ms\n", pct(0.90))
	fmt.Printf("latency p99 : %d ms\n", pct(0.99))
	fmt.Printf("latency max : %d ms\n", pct(1.0))

	// 2) health after
	h, err := http.Get(base + "/health")
	if err == nil {
		out, _ := io.ReadAll(h.Body)
		h.Body.Close()
		fmt.Printf("\n--- gateway health ---\n%s\n", string(out))
		var m map[string]interface{}
		if json.Unmarshal(out, &m) == nil {
			fwd, _ := m["forwarded"].(float64)
			dup, _ := m["duplicates"].(float64)
			fail, _ := m["failed"].(float64)
			rej, _ := m["rejected"].(float64)
			expectedFwd := float64(*total)
			fmt.Printf("\nforwarded=%v (expected %v, unique events)\n", fwd, expectedFwd)
			fmt.Printf("duplicates=%v (expected >= %d)\n", dup, dupCount)
			fmt.Printf("failed=%v rejected=%v\n", fail, rej)
		}
	}

	if bad*100 > len(jobs) {
		fmt.Println("\nRESULT: FAIL (error rate > 1%)")
		os.Exit(1)
	}
	fmt.Println("\nRESULT: PASS (error rate <= 1%)")
}