package main

import (
	"bytes"
	"crypto/ed25519"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	hdrSig = "X-Signature-Ed25519"
	hdrTs  = "X-Signature-Timestamp"

	// 去重窗口：同一 event id 在此时间内只转发一次
	dedupWindow = 30 * time.Minute
	// 去重缓存清理周期
	sweepInterval = 3 * time.Minute
	// 转发给海豹的超时
	forwardTimeout = 30 * time.Second
	// 请求体上限
	maxBodyBytes = 8 << 20
	// 转发失败重试次数
	forwardRetries = 4
	// 转发并发上限，避免打满海豹的 accept 队列
	forwardConcurrency = 4
)

type frpConfig struct {
	Enabled    bool   `json:"enabled"`
	ServerAddr string `json:"serverAddr"`
	ServerPort int    `json:"serverPort"`
	Token      string `json:"token"`
	RemotePort int    `json:"remotePort"`
	LocalPort  int    `json:"localPort"`
	Name       string `json:"name"`
}

type behaviorConfig struct {
	Retries      int `json:"retries"`
	Concurrency  int `json:"concurrency"`
	DedupMinutes int `json:"dedupMinutes"`
}

type config struct {
	Listen    string         `json:"listen"`
	Path      string         `json:"path"`
	Forward   string         `json:"forward"`
	AppSecret string         `json:"appSecret"`
	Secret    string         `json:"secret"`
	Frp       frpConfig      `json:"frp"`
	Behavior  behaviorConfig `json:"behavior"`
}

type gateway struct {
	secret  string
	path    string
	forward string
	client  *http.Client
	limit   chan struct{}
	retries int
	dedup   time.Duration

	mu   sync.Mutex
	seen map[string]time.Time
	stat statistics
}

type statistics struct {
	received  int64
	acked     int64
	duplicate int64
	validated int64
	forwarded int64
	failed    int64
	rejected  int64
	lastError string
	lastFwd   string
}

// ---------- ed25519 ----------

func seedOf(secret string) []byte {
	s := secret
	for len(s) < ed25519.SeedSize {
		s = strings.Repeat(s, 2)
	}
	return []byte(s[:ed25519.SeedSize])
}

func privOf(secret string) ed25519.PrivateKey {
	return ed25519.NewKeyFromSeed(seedOf(secret))
}

// verify 校验 QQ 回调签名：签名对象为 timestamp + body
func verify(secret, ts string, body []byte, sigHex string) bool {
	if ts == "" || sigHex == "" {
		return false
	}
	sig, err := hex.DecodeString(sigHex)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return false
	}
	pub := privOf(secret).Public().(ed25519.PublicKey)
	return ed25519.Verify(pub, append([]byte(ts), body...), sig)
}

// signValidation 生成 op=13 校验应答签名：签名对象为 event_ts + plain_token
func signValidation(secret, eventTs, plainToken string) string {
	return hex.EncodeToString(ed25519.Sign(privOf(secret), append([]byte(eventTs), []byte(plainToken)...)))
}

// ---------- helpers ----------

func asString(v interface{}) string {
	switch t := v.(type) {
	case string:
		return t
	case json.Number:
		return t.String()
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	case bool:
		return strconv.FormatBool(t)
	case nil:
		return ""
	default:
		b, _ := json.Marshal(t)
		return string(b)
	}
}

type eventPayload struct {
	Op int             `json:"op"`
	D  json.RawMessage `json:"d"`
	ID string          `json:"id"`
	T  string          `json:"t"`
}

// ---------- dedup ----------

func (g *gateway) isDuplicate(id string) bool {
	if id == "" {
		return false
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	if _, ok := g.seen[id]; ok {
		g.stat.duplicate++
		return true
	}
	g.seen[id] = time.Now()
	return false
}

func (g *gateway) sweep() {
	for {
		time.Sleep(sweepInterval)
		cut := time.Now().Add(-g.dedup)
		g.mu.Lock()
		for k, t := range g.seen {
			if t.Before(cut) {
				delete(g.seen, k)
			}
		}
		n := len(g.seen)
		g.mu.Unlock()
		log.Printf("dedup cache cleaned, size=%d", n)
	}
}

// ---------- forwarding ----------

func (g *gateway) doForward(raw []byte, ts, sig string) {
	// 并发闸门：避免瞬间打满海豹的 accept 队列
	g.limit <- struct{}{}
	defer func() { <-g.limit }()

	var lastErr error
	for attempt := 1; attempt <= g.retries; attempt++ {
		req, err := http.NewRequest(http.MethodPost, g.forward, bytes.NewReader(raw))
		if err != nil {
			g.bump(func(s *statistics) { s.failed++; s.lastError = err.Error() })
			log.Printf("forward build error: %v", err)
			return
		}
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set(hdrTs, ts)
		req.Header.Set(hdrSig, sig)

		resp, err := g.client.Do(req)
		if err == nil {
			out, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
			resp.Body.Close()
			if resp.StatusCode >= 200 && resp.StatusCode < 300 {
				g.bump(func(s *statistics) {
					s.forwarded++
					s.lastFwd = resp.Status + " " + strings.TrimSpace(string(out))
				})
				if attempt > 1 {
					log.Printf("forward -> %d %s (attempt %d)", resp.StatusCode, strings.TrimSpace(string(out)), attempt)
				}
				return
			}
			lastErr = fmt.Errorf("http %d: %s", resp.StatusCode, strings.TrimSpace(string(out)))
		} else {
			lastErr = err
		}

		if attempt < g.retries {
			backoff := time.Duration(attempt*attempt) * 60 * time.Millisecond
			log.Printf("forward failed (attempt %d/%d): %v; retry in %s", attempt, g.retries, lastErr, backoff)
			time.Sleep(backoff)
		}
	}

	g.bump(func(s *statistics) { s.failed++; s.lastError = lastErr.Error() })
	log.Printf("forward gave up after %d attempts: %v", g.retries, lastErr)
}

func (g *gateway) bump(fn func(*statistics)) {
	g.mu.Lock()
	fn(&g.stat)
	g.mu.Unlock()
}

// ---------- http handlers ----------

func (g *gateway) handle(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != g.path {
		http.NotFound(w, r)
		return
	}

	raw, err := io.ReadAll(io.LimitReader(r.Body, maxBodyBytes))
	_ = r.Body.Close()
	if err != nil {
		http.Error(w, "read body failed", http.StatusBadRequest)
		return
	}

	ts := r.Header.Get(hdrTs)
	sig := r.Header.Get(hdrSig)
	g.bump(func(s *statistics) { s.received++ })

	if !verify(g.secret, ts, raw, sig) {
		g.bump(func(s *statistics) { s.rejected++ })
		log.Printf("signature verify failed, len=%d", len(raw))
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	var p eventPayload
	if err := json.Unmarshal(raw, &p); err != nil {
		http.Error(w, "bad json", http.StatusBadRequest)
		return
	}

	// op=13：QQ 后台保存回调地址时的校验
	if p.Op == 13 {
		var d map[string]interface{}
		if err := json.Unmarshal(p.D, &d); err != nil {
			http.Error(w, "bad validation payload", http.StatusBadRequest)
			return
		}
		token := asString(d["plain_token"])
		eventTs := asString(d["event_ts"])
		rsp, _ := json.Marshal(map[string]string{
			"plain_token": token,
			"signature":   signValidation(g.secret, eventTs, token),
		})
		g.bump(func(s *statistics) { s.validated++ })
		log.Printf("op=13 validation ok, event_ts=%s", eventTs)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write(rsp)
		return
	}

	// op=0：事件分发。先 ACK，再异步转发，避免 QQ 因超时重投
	w.Header().Set("Content-Type", "application/json")
	if p.Op == 0 {
		dup := g.isDuplicate(p.ID)
		g.bump(func(s *statistics) { s.acked++ })
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`{"op":12,"d":0}`))
		if dup {
			log.Printf("duplicate skipped, id=%s type=%s", p.ID, p.T)
			return
		}
		go g.doForward(raw, ts, sig)
		return
	}

	// 其它 op：直接 ACK，不转发
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(`{"op":12,"d":0}`))
}

func (g *gateway) health(w http.ResponseWriter, _ *http.Request) {
	g.mu.Lock()
	out := map[string]interface{}{
		"ok":         true,
		"path":       g.path,
		"forward":    g.forward,
		"received":   g.stat.received,
		"validated":  g.stat.validated,
		"acked":      g.stat.acked,
		"duplicates": g.stat.duplicate,
		"forwarded":  g.stat.forwarded,
		"failed":     g.stat.failed,
		"rejected":   g.stat.rejected,
		"lastError":  g.stat.lastError,
		"lastFwd":    g.stat.lastFwd,
		"cache":      len(g.seen),
		"retries":     g.retries,
		"concurrency": cap(g.limit),
		"dedupMin":    int(g.dedup.Minutes()),
	}
	g.mu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(out)
}

// ---------- main ----------

func loadConfigFile(path string) (*config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c config
	if err := json.Unmarshal(b, &c); err != nil {
		return nil, err
	}
	return &c, nil
}

func main() {
	var (
		cfgPath = flag.String("config", "", "config json file path")
		listen  = flag.String("listen", "127.0.0.1:9092", "listen address")
		path    = flag.String("path", "/qq/callback", "callback path")
		forward = flag.String("forward", "http://127.0.0.1:8099/qq/callback", "sealdice webhook url")
		secret  = flag.String("secret", "", "QQ bot app secret")
	)
	flag.Parse()

	cfg := &config{Listen: *listen, Path: *path, Forward: *forward, Secret: *secret}

	if *cfgPath != "" {
		fileCfg, err := loadConfigFile(*cfgPath)
		if err != nil {
			log.Fatalf("load config failed: %v", err)
		}
		if fileCfg.Listen != "" {
			cfg.Listen = fileCfg.Listen
		}
		if fileCfg.Path != "" {
			cfg.Path = fileCfg.Path
		}
		if fileCfg.Forward != "" {
			cfg.Forward = fileCfg.Forward
		}
		if fileCfg.AppSecret != "" {
			cfg.Secret = fileCfg.AppSecret
		}
		if fileCfg.Secret != "" {
			cfg.Secret = fileCfg.Secret
		}
		cfg.Frp = fileCfg.Frp
		cfg.Behavior = fileCfg.Behavior
	}
	if cfg.Behavior.Retries <= 0 {
		cfg.Behavior.Retries = forwardRetries
	}
	if cfg.Behavior.Concurrency <= 0 {
		cfg.Behavior.Concurrency = forwardConcurrency
	}
	if cfg.Behavior.DedupMinutes <= 0 {
		cfg.Behavior.DedupMinutes = int(dedupWindow.Minutes())
	}

	// 命令行显式传入的优先于配置文件
	set := map[string]bool{}
	flag.Visit(func(f *flag.Flag) { set[f.Name] = true })
	if set["listen"] {
		cfg.Listen = *listen
	}
	if set["path"] {
		cfg.Path = *path
	}
	if set["forward"] {
		cfg.Forward = *forward
	}
	if set["secret"] {
		cfg.Secret = *secret
	}

	if strings.TrimSpace(cfg.Secret) == "" {
		log.Fatal("missing app secret: use -secret or -config")
	}
	if !strings.HasPrefix(cfg.Path, "/") {
		log.Fatal("path must start with /")
	}

	transport := &http.Transport{
		MaxIdleConns:        32,
		MaxIdleConnsPerHost: 8,
		IdleConnTimeout:     60 * time.Second,
		DisableCompression:  true,
	}
	g := &gateway{
		secret:  cfg.Secret,
		path:    cfg.Path,
		forward: cfg.Forward,
		client:  &http.Client{Timeout: forwardTimeout, Transport: transport},
		limit:   make(chan struct{}, cfg.Behavior.Concurrency),
		retries: cfg.Behavior.Retries,
		dedup:   time.Duration(cfg.Behavior.DedupMinutes) * time.Minute,
		seen:    map[string]time.Time{},
	}

	go g.sweep()

	mux := http.NewServeMux()
	mux.HandleFunc("/health", g.health)
	mux.HandleFunc("/", g.handle)

	if cfg.Frp.Enabled {
		if err := startFrp(cfg); err != nil {
			log.Printf("frp start failed: %v", err)
		}
	}

	log.Printf("qq webhook gateway listening=%s path=%s forward=%s retries=%d concurrency=%d dedup=%dm",
		cfg.Listen, cfg.Path, cfg.Forward, cfg.Behavior.Retries, cfg.Behavior.Concurrency, cfg.Behavior.DedupMinutes)
	srv := &http.Server{
		Addr:              cfg.Listen,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatalf("server error: %v", err)
	}
}

// 供文档引用，避免误删
var _ = fmt.Sprintf
// startFrp 在配置启用时拉起同目录的 frpc，并写入临时 toml。
func startFrp(cfg *config) error {
	if cfg.Frp.ServerAddr == "" {
		return errors.New("frp.serverAddr 为空")
	}
	exePath, err := os.Executable()
	if err != nil {
		return err
	}
	dir := filepath.Dir(exePath)
	frpc := filepath.Join(dir, "frpc.exe")
	if _, err := os.Stat(frpc); err != nil {
		return fmt.Errorf("未找到 frpc.exe: %w", err)
	}
	localPort := cfg.Frp.LocalPort
	if localPort == 0 {
		if _, p, e := net.SplitHostPort(cfg.Listen); e == nil {
			localPort, _ = strconv.Atoi(p)
		}
	}
	name := cfg.Frp.Name
	if name == "" {
		name = "qqbridge"
	}
	serverPort := cfg.Frp.ServerPort
	if serverPort == 0 {
		serverPort = 7000
	}
	toml := fmt.Sprintf("serverAddr = %q\nserverPort = %d\n\n", cfg.Frp.ServerAddr, serverPort)
	toml += "auth.method = \"token\"\n"
	toml += fmt.Sprintf("auth.token = %q\n\n", cfg.Frp.Token)
	toml += "[[proxies]]\n"
	toml += fmt.Sprintf("name = %q\n", name)
	toml += "type = \"tcp\"\n"
	toml += "localIP = \"127.0.0.1\"\n"
	toml += fmt.Sprintf("localPort = %d\n", localPort)
	toml += fmt.Sprintf("remotePort = %d\n", cfg.Frp.RemotePort)
	toml += "\ntransport.useEncryption = true\ntransport.useCompression = true\n"

	tomlPath := filepath.Join(dir, "frpc.generated.toml")
	if err := os.WriteFile(tomlPath, []byte(toml), 0o644); err != nil {
		return err
	}
	cmd := exec.Command(frpc, "-c", tomlPath)
	cmd.Dir = dir
	logPath := filepath.Join(dir, "frpc.log")
	lf, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err == nil {
		cmd.Stdout = lf
		cmd.Stderr = lf
	}
	if err := cmd.Start(); err != nil {
		return err
	}
	log.Printf("frpc started (pid=%d) remote=%s:%d local=127.0.0.1:%d log=%s",
		cmd.Process.Pid, cfg.Frp.ServerAddr, cfg.Frp.RemotePort, localPort, logPath)
	go func() { _ = cmd.Wait() }()
	return nil
}