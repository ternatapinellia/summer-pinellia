package main

import (
	"bytes"
	"crypto/ed25519"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

func keyOf(secret string) (ed25519.PublicKey, ed25519.PrivateKey) {
	seed := secret
	for len(seed) < ed25519.SeedSize {
		seed = strings.Repeat(seed, 2)
	}
	pub, priv, err := ed25519.GenerateKey(strings.NewReader(seed[:ed25519.SeedSize]))
	if err != nil {
		panic(err)
	}
	return pub, priv
}

func main() {
	secret := flag.String("secret", "", "QQ bot app secret")
	url := flag.String("url", "", "full callback url, e.g. https://example/qq/callback")
	flag.Parse()
	if *secret == "" || *url == "" {
		fmt.Println("usage: qqwh-verify -secret <appsecret> -url https://your.domain/qq/callback")
		return
	}

	base := strings.TrimSuffix(*url, "/qq/callback")
	_, priv := keyOf(*secret)

	post := func(body, ts string) (int, string) {
		sig := hex.EncodeToString(ed25519.Sign(priv, append([]byte(ts), []byte(body)...)))
		req, _ := http.NewRequest("POST", *url, bytes.NewReader([]byte(body)))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Signature-Timestamp", ts)
		req.Header.Set("X-Signature-Ed25519", sig)
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			return -1, err.Error()
		}
		defer resp.Body.Close()
		out, _ := io.ReadAll(resp.Body)
		return resp.StatusCode, strings.TrimSpace(string(out))
	}

	ts := fmt.Sprintf("%d", time.Now().Unix())
	val := fmt.Sprintf("{\"op\":13,\"d\":{\"plain_token\":\"v%s\",\"event_ts\":\"%s\"}}", ts[6:], ts)
	st, bd := post(val, ts)
	ok13 := st == 200 && strings.Contains(bd, "\"signature\"")
	fmt.Printf("[1] op=13  callback validation : status=%d ok=%v\n", st, ok13)
	if !ok13 {
		fmt.Printf("    body: %s\n", bd)
	}

	ev := fmt.Sprintf("VERIFY_%d", time.Now().Unix())
	body := fmt.Sprintf("{\"op\":0,\"id\":\"%s\",\"t\":\"GROUP_AT_MESSAGE_CREATE\",\"d\":{\"content\":\"verify\"}}", ev)
	for i := 1; i <= 3; i++ {
		st, _ = post(body, ts)
		fmt.Printf("[2.%d] event delivery #%d        : status=%d\n", i, i, st)
		time.Sleep(900 * time.Millisecond)
	}

	h, err := http.Get(base + "/health")
	if err != nil {
		fmt.Println("[3] health check: ERR", err)
		return
	}
	out, _ := io.ReadAll(h.Body)
	h.Body.Close()
	var m map[string]interface{}
	_ = json.Unmarshal(out, &m)
	fmt.Printf("[3] gateway health            : %s\n", string(out))
	if d, ok := m["duplicates"].(float64); ok && d >= 2 {
		fmt.Println("RESULT: PASS  (dedup working, duplicates >= 2)")
	} else {
		fmt.Println("RESULT: dedup counter not >= 2, please check")
	}
}