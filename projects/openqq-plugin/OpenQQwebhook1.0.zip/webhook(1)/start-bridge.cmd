@echo off
cd /d "%~dp0"
start "QQ Official Webhook Bridge" "%~dp0QQOfficial-Webhook-HTTPS-Bridge.exe"
