@echo off
cd /d "%~dp0"
if not exist "%~dp0Caddy\caddy.exe" (
  echo [ERROR] Caddy\caddy.exe not found.
  echo Please install/download Caddy into the Caddy folder first.
  pause
  exit /b 1
)
start "Caddy HTTPS" "%~dp0Caddy\caddy.exe" run --config "%~dp0Caddyfile"
