Write-Host "Caddy is the HTTPS/TLS component for this bridge." -ForegroundColor Cyan
Write-Host "Download the Windows amd64 Caddy binary from the official Caddy site and place caddy.exe in .\Caddy\caddy.exe" -ForegroundColor Yellow
Write-Host "Then edit Caddyfile with this server's own domain." -ForegroundColor Yellow
