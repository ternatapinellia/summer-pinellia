QQ Official Webhook HTTPS Bridge v2.0

部署版：QQOfficial-Webhook-HTTPS-Bridge.exe
无需 Python / 无需安装 Python 才能运行 EXE。

目录：
  QQOfficial-Webhook-HTTPS-Bridge.exe
  config\bots.json
  Caddyfile
  logs\bridge.log（运行后自动生成）

1. 编辑 config\bots.json
   每个 Bot 填自己的 AppID + Secret。
   同一台服务器的多个 Bot 可以共用一个 HTTPS 回调地址，Bridge 根据 X-Bot-Appid 自动选择 Secret。

2. Bridge 默认监听：127.0.0.1:9092
   QQ 回调地址：你的域名/qq/callback

3. HTTPS 由 Caddy 负责：
   Caddyfile：你的独立域名 -> 127.0.0.1:9092
   每台服务器可以使用自己的独立域名，不需要子域名。

4. QQ 官方后台 Webhook URL 填：
   https://你的域名/qq/callback

5. op=13 验证、Ed25519 签名校验、事件 ACK、按 Bot 转发均由 EXE 完成。

如果使用 forward_url：
   Bridge 会把已验签的原始 QQ JSON POST 到对应地址。
   forward_required=true 时转发失败会返回 500；false 时仍 ACK QQ。
