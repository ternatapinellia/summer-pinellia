# -*- coding: utf-8 -*-
"""OpenQQ QQ Sync Bridge v2.0 - multi SeaDice instance edition."""
import argparse, json, os, sqlite3, time, sys, secrets, smtplib, ssl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from email.message import EmailMessage

VERSION = "2.0"
DEFAULT_PORT = 38999
PORT_FILE_NAME = "bridge_port.txt"


def root_dir():
    # PyInstaller 冻结后 __file__ 指向 _MEI 临时目录，不能从那里找 SeaDice 数据。
    # 应始终以 EXE 所在目录作为桥的工作根目录。
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def path_from_root(p):
    return os.path.normpath(p if os.path.isabs(p) else os.path.join(root_dir(), p))


EMAIL_CONFIG_NAME = "email_config.json"
BINDINGS_FILE_NAME = "bridge_bindings.json"


def mask_email(addr):
    try:
        local, domain = addr.split("@", 1)
        if len(local) <= 2:
            masked = local[0] + "*" * max(1, len(local) - 1)
        else:
            masked = local[0] + "*" * (len(local) - 2) + local[-1]
        return masked + "@" + domain
    except Exception:
        return "******"



class Bridge:
    def __init__(self, data_dir):
        self.data_dir = path_from_root(data_dir)
        self.db_path = os.path.join(self.data_dir, "data.db")
        self.logs_path = os.path.join(self.data_dir, "data-logs.db")
        self.port_file = os.path.join(root_dir(), PORT_FILE_NAME)
        self.email_config_file = os.path.join(root_dir(), EMAIL_CONFIG_NAME)
        self.bindings_file = os.path.join(root_dir(), BINDINGS_FILE_NAME)
        self.pending_codes = {}

    def load_email_config(self):
        if not os.path.isfile(self.email_config_file):
            raise RuntimeError(f"email config not found: {self.email_config_file}")
        try:
            with open(self.email_config_file, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception as e:
            raise RuntimeError(f"email config invalid: {e}")
        required = ["sender_email", "smtp_host", "smtp_port", "smtp_password"]
        missing = [k for k in required if not str(cfg.get(k, "")).strip()]
        if missing:
            raise RuntimeError("email config missing: " + ", ".join(missing))
        cfg["smtp_port"] = int(cfg.get("smtp_port", 465))
        cfg["smtp_user"] = str(cfg.get("smtp_user") or cfg["sender_email"]).strip()
        cfg["smtp_ssl"] = bool(cfg.get("smtp_ssl", True))
        return cfg

    def send_verification_email(self, recipient, old, old_group, current, target_group, code):
        cfg = getattr(self, "runtime_email_config", None) or self.load_email_config()
        msg = EmailMessage()
        msg["Subject"] = "OpenQQ旧QQ数据迁移验证码"
        msg["From"] = cfg["sender_email"]
        msg["To"] = recipient
        msg.set_content(
            "OpenQQ 旧QQ数据迁移验证\n\n"
            f"旧QQ：{old}\n"
            f"旧群：{old_group}\n"
            f"当前OpenQQ用户：{current}\n"
            f"当前群：{target_group}\n\n"
            f"验证码：{code}\n\n"
            "验证码有效期：5分钟。\n"
            "如果不是你本人发起的操作，请忽略此邮件。"
        )
        if cfg["smtp_ssl"]:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(cfg["smtp_host"], cfg["smtp_port"], context=context, timeout=30) as s:
                s.login(cfg["smtp_user"], cfg["smtp_password"])
                s.send_message(msg)
        else:
            with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"], timeout=30) as s:
                s.ehlo()
                if cfg.get("smtp_starttls", True):
                    s.starttls(context=ssl.create_default_context())
                    s.ehlo()
                s.login(cfg["smtp_user"], cfg["smtp_password"])
                s.send_message(msg)

    def binding_key(self, old, old_group):
        return f"{old}|{old_group}"

    def load_bindings(self):
        try:
            with open(self.bindings_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def save_bindings(self, data):
        tmp = self.bindings_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.bindings_file)

    def set_email_config(self, cfg):
        required = ["sender_email", "smtp_host", "smtp_port", "smtp_password"]
        missing = [k for k in required if not str(cfg.get(k, "")).strip()]
        if missing:
            raise RuntimeError("邮箱配置缺少：" + ", ".join(missing))
        sender = str(cfg.get("sender_email", "")).strip()
        if "@" not in sender or "." not in sender.rsplit("@", 1)[-1]:
            raise RuntimeError("发件邮箱格式不正确")
        port = int(cfg.get("smtp_port", 465))
        if not 1 <= port <= 65535:
            raise RuntimeError("SMTP端口不正确")
        self.runtime_email_config = {
            "sender_email": sender,
            "smtp_user": str(cfg.get("sender_email") or sender).strip(),
            "smtp_host": str(cfg.get("smtp_host") or "smtp.qq.com").strip(),
            "smtp_port": port,
            "smtp_password": str(cfg.get("smtp_password") or ""),
            "smtp_ssl": bool(cfg.get("smtp_ssl", True)),
        }
        return {"ok": True, "email": mask_email(sender)}

    def get_runtime_email_config(self):
        cfg = getattr(self, "runtime_email_config", None)
        if not cfg:
            raise RuntimeError("请先在SeaDice插件配置中填写邮箱设置")
        return cfg

    def send_email_message(self, msg):
        """统一SMTP发送流程；测试邮件与验证码邮件使用完全相同的连接/认证逻辑。"""
        cfg = getattr(self, "runtime_email_config", None) or self.load_email_config()
        if cfg.get("smtp_ssl", True):
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(cfg["smtp_host"], cfg["smtp_port"], context=context, timeout=30) as s:
                s.ehlo()
                s.login(cfg["smtp_user"], cfg["smtp_password"])
                s.send_message(msg)
        else:
            with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"], timeout=30) as s:
                s.ehlo()
                if cfg.get("smtp_starttls", True):
                    s.starttls(context=ssl.create_default_context())
                    s.ehlo()
                s.login(cfg["smtp_user"], cfg["smtp_password"])
                s.send_message(msg)

    def send_test_email(self):
        cfg = self.get_runtime_email_config()
        msg = EmailMessage()
        msg["Subject"] = "OpenQQ QQ Sync Bridge 邮箱测试"
        msg["From"] = cfg["sender_email"]
        msg["To"] = cfg["sender_email"]
        msg.set_content("这是 OpenQQ QQ Sync Bridge 的测试邮件。\n\n如果你能收到这封邮件，说明发件邮箱和 SMTP 授权码配置正确。")
        self.send_email_message(msg)
        return {"ok": True, "email": mask_email(cfg["sender_email"])}

    def request_code(self, old, old_group, current, target_group):
        # Refuse a source QQ/group that is already bound to a different target.
        bindings = self.load_bindings()
        key = self.binding_key(old, old_group)
        existing = bindings.get(key)
        if existing and (existing.get("current") != current or existing.get("group") != target_group):
            raise RuntimeError("该旧QQ/旧群已经绑定到其他OpenQQ账号或群，为防止误绑，本次操作已拒绝。")

        # Confirm source data exists before sending mail.
        info = self.lookup(old)
        if not info.get("character_count"):
            raise RuntimeError("该旧QQ没有找到可迁移的角色卡数据。")

        code = f"{secrets.randbelow(1000000):06d}"
        now = time.time()
        pending_key = f"{old}|{old_group}|{current}|{target_group}"
        recipient = f"{old}@qq.com"
        self.send_verification_email(recipient, old, old_group, current, target_group, code)
        self.pending_codes[pending_key] = {
            "code": code,
            "expires": now + 300,
            "attempts": 0,
            "old": old,
            "old_group": old_group,
            "current": current,
            "group": target_group,
        }
        return {"ok": True, "email": mask_email(recipient), "expires_in": 300}

    def verify_code_and_bind(self, old, old_group, current, target_group, code):
        pending_key = f"{old}|{old_group}|{current}|{target_group}"
        item = self.pending_codes.get(pending_key)
        if not item:
            raise RuntimeError("没有找到待验证的请求，请重新执行 .旧QQ绑定。")
        if time.time() > item["expires"]:
            self.pending_codes.pop(pending_key, None)
            raise RuntimeError("验证码已过期，请重新获取。")
        item["attempts"] += 1
        if item["attempts"] > 5:
            self.pending_codes.pop(pending_key, None)
            raise RuntimeError("验证码错误次数过多，请重新获取。")
        if not secrets.compare_digest(str(code).strip(), item["code"]):
            remain = max(0, 5 - item["attempts"])
            raise RuntimeError(f"验证码错误，还可尝试 {remain} 次。")

        bindings = self.load_bindings()
        key = self.binding_key(old, old_group)
        existing = bindings.get(key)
        if existing and (existing.get("current") != current or existing.get("group") != target_group):
            self.pending_codes.pop(pending_key, None)
            raise RuntimeError("该旧QQ/旧群已经绑定到其他OpenQQ账号或群，为防止误绑，本次操作已拒绝。")

        result = self.bind(old, current, target_group, old_group)
        bindings[key] = {
            "current": current,
            "group": target_group,
            "bound_at": int(time.time()),
        }
        self.save_bindings(bindings)
        self.pending_codes.pop(pending_key, None)
        return result

    def check(self):
        if not os.path.isfile(self.db_path):
            raise RuntimeError(f"data.db not found: {self.db_path}")
        if not os.path.isfile(self.logs_path):
            raise RuntimeError(f"data-logs.db not found: {self.logs_path}")

    def connect(self, path):
        self.check()
        con = sqlite3.connect(path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=30000")
        return con

    def backup_db_before_bind(self):
        # Use SQLite backup API so WAL contents are included in the snapshot.
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup = self.db_path + ".before-sync-" + stamp + ".bak"
        src = sqlite3.connect(self.db_path, timeout=30)
        try:
            dst = sqlite3.connect(backup)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        return backup

    def backup_logs_before_bind(self):
        # Use SQLite backup API so data-logs.db WAL contents are included too.
        stamp = time.strftime("%Y%m%d-%H%M%S")
        backup = self.logs_path + ".before-sync-" + stamp + ".bak"
        src = sqlite3.connect(self.logs_path, timeout=30)
        try:
            dst = sqlite3.connect(backup)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        return backup

    @staticmethod
    def row_dict(row):
        return dict(row) if row else None

    def log_error(self, message):
        try:
            stamp = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(os.path.join(self.data_dir, "bridge_error.log"), "a", encoding="utf-8") as f:
                f.write(f"[{stamp}] {message}\n")
        except Exception:
            pass

    def save_port(self, port):
        if not 1 <= int(port) <= 65535:
            raise RuntimeError("Invalid port")
        tmp = self.port_file + ".tmp"
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            f.write(str(int(port)) + "\n")
        os.replace(tmp, self.port_file)
        return int(port)

    def read_saved_port(self):
        try:
            with open(self.port_file, "r", encoding="utf-8") as f:
                p = int(f.read().strip())
                if 1 <= p <= 65535:
                    return p
        except Exception:
            pass
        return DEFAULT_PORT

    def lookup(self, old):
        owner = "QQ:" + old
        with self.connect(self.db_path) as con:
            rows = con.execute(
                "SELECT id, attrs_type, binding_sheet_id, name, owner_id, sheet_type, "
                "is_hidden, created_at, updated_at, length(data) AS data_size "
                "FROM attrs WHERE owner_id=? ORDER BY updated_at DESC", (owner,)
            ).fetchall()
        chars = [dict(r) for r in rows if r["attrs_type"] in ("character", "coc7", "dnd5e", "st") or (r["name"] and r["data_size"] is not None)]
        return {"ok": True, "characters": chars, "character_count": len(chars)}

    def migrate_logs(self, old_group_id, target_group):
        """Copy logs/log_items from old_group_id to target_group with remapped IDs."""
        if not os.path.isfile(self.logs_path):
            raise RuntimeError(f"data-logs.db not found: {self.logs_path}")

        con = sqlite3.connect(self.logs_path, timeout=30)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=30000")
        try:
            con.execute("BEGIN IMMEDIATE")
            old_logs = con.execute(
                "SELECT id,name,group_id,created_at,updated_at,size,extra,upload_url,upload_time "
                "FROM logs WHERE group_id=? ORDER BY id ASC", (old_group_id,)
            ).fetchall()
            if not old_logs:
                con.commit()
                return {"log_count": 0, "log_item_count": 0, "log_skipped": 0}

            max_log_id = int(con.execute("SELECT COALESCE(MAX(id),0) FROM logs").fetchone()[0] or 0)
            max_item_id = int(con.execute("SELECT COALESCE(MAX(id),0) FROM log_items").fetchone()[0] or 0)
            next_log_id = max_log_id + 1
            next_item_id = max_item_id + 1

            log_map = {}
            copied_source_logs = set()
            skipped_logs = 0

            for log in old_logs:
                duplicate = con.execute(
                    "SELECT id FROM logs WHERE group_id=? AND name=? AND created_at=? ORDER BY id LIMIT 1",
                    (target_group, log["name"], log["created_at"]),
                ).fetchone()
                if duplicate:
                    log_map[int(log["id"])] = int(duplicate["id"])
                    skipped_logs += 1
                    continue
                new_id = next_log_id
                next_log_id += 1
                con.execute(
                    "INSERT INTO logs(id,name,group_id,created_at,updated_at,size,extra,upload_url,upload_time) VALUES(?,?,?,?,?,?,?,?,?)",
                    (new_id, log["name"], target_group, log["created_at"], log["updated_at"],
                     log["size"], log["extra"], log["upload_url"], log["upload_time"]),
                )
                log_map[int(log["id"])] = new_id
                copied_source_logs.add(int(log["id"]))

            source_ids = list(copied_source_logs)
            if not source_ids:
                con.commit()
                return {"log_count": 0, "log_item_count": 0, "log_skipped": skipped_logs}

            placeholders = ",".join("?" for _ in source_ids)
            items = con.execute(
                f"SELECT id,log_id,group_id,nickname,im_userid,time,message,is_dice,command_id,command_info,raw_msg_id,user_uniform_id,removed,parent_id "
                f"FROM log_items WHERE log_id IN ({placeholders}) ORDER BY id ASC", source_ids
            ).fetchall()

            item_map = {}
            copied_items = 0
            for item in items:
                new_item_id = next_item_id
                next_item_id += 1
                item_map[int(item["id"])] = new_item_id
                con.execute(
                    "INSERT INTO log_items(id,log_id,group_id,nickname,im_userid,time,message,is_dice,command_id,command_info,raw_msg_id,user_uniform_id,removed,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (new_item_id, log_map[int(item["log_id"])], target_group, item["nickname"], item["im_userid"],
                     item["time"], item["message"], item["is_dice"], item["command_id"], item["command_info"],
                     item["raw_msg_id"], item["user_uniform_id"], item["removed"],
                     item_map.get(int(item["parent_id"])) if item["parent_id"] is not None else None),
                )
                copied_items += 1

            con.commit()
            return {"log_count": len(copied_source_logs), "log_item_count": copied_items, "log_skipped": skipped_logs}
        except Exception:
            try:
                con.rollback()
            except Exception:
                pass
            raise
        finally:
            con.close()

    def bind(self, old, current, target_group, old_group):
        old_owner = "QQ:" + old
        old_group_id = "QQ-Group:" + old_group
        now = int(time.time() * 1000)
        backup_path = self.backup_db_before_bind()
        logs_backup_path = self.backup_logs_before_bind()
        con = None
        try:
            con = self.connect(self.db_path)
            con.execute("PRAGMA foreign_keys=ON")
            con.execute("BEGIN IMMEDIATE")

            char_rows = con.execute(
                "SELECT id,data,attrs_type,binding_sheet_id,name,owner_id,sheet_type,is_hidden,created_at,updated_at "
                "FROM attrs WHERE owner_id=? ORDER BY updated_at DESC", (old_owner,)
            ).fetchall()

            exact_id = old_group_id + "-" + old_owner
            attr_rows = con.execute(
                "SELECT id,data,attrs_type,binding_sheet_id,name,owner_id,sheet_type,is_hidden,created_at,updated_at "
                "FROM attrs WHERE id=? OR (id LIKE ? AND owner_id=?) ORDER BY length(data) DESC",
                (exact_id, exact_id + "%", old_owner),
            ).fetchall()

            gp = con.execute(
                "SELECT name,last_command_time,auto_set_name_template,dice_side_num,created_at,updated_at "
                "FROM group_player_info WHERE user_id=? AND group_id=? ORDER BY updated_at DESC LIMIT 1",
                (old_owner, old_group_id),
            ).fetchone()

            copied_chars = []
            skipped_empty = []
            for a in char_rows:
                raw = bytes(a["data"] or b"")
                if len(raw) <= 23:
                    skipped_empty.append(a["name"] or a["id"])
                    continue
                # IMPORTANT: create a new ID for the copied owner. Reusing the old
                # primary key would UPDATE/move the old card instead of copying it.
                old_id = str(a["id"])
                new_id = old_id
                # Prefer a deterministic suffix that remains stable across retries.
                if a["owner_id"] != current:
                    new_id = old_id + "-openqq-" + current.replace(":", "_")
                # Avoid collisions by checking first.
                if con.execute("SELECT 1 FROM attrs WHERE id=?", (new_id,)).fetchone():
                    # If the existing row already belongs to current owner, update it;
                    # otherwise create a unique ID.
                    owner_row = con.execute("SELECT owner_id FROM attrs WHERE id=?", (new_id,)).fetchone()
                    if owner_row and owner_row["owner_id"] != current:
                        base = new_id
                        n = 2
                        while con.execute("SELECT 1 FROM attrs WHERE id=?", (f"{base}-{n}",)).fetchone():
                            n += 1
                        new_id = f"{base}-{n}"
                con.execute(
                    "INSERT INTO attrs(id,data,attrs_type,binding_sheet_id,name,owner_id,sheet_type,is_hidden,created_at,updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(id) DO UPDATE SET data=excluded.data,attrs_type=excluded.attrs_type,"
                    "binding_sheet_id=excluded.binding_sheet_id,name=excluded.name,owner_id=excluded.owner_id,"
                    "sheet_type=excluded.sheet_type,is_hidden=excluded.is_hidden,updated_at=excluded.updated_at",
                    (new_id, raw, a["attrs_type"], a["binding_sheet_id"], a["name"], current,
                     a["sheet_type"], a["is_hidden"], a["created_at"] or now, now),
                )
                copied_chars.append(a["name"] or new_id)

            copied_attrs = 0
            if attr_rows:
                a = attr_rows[0]
                target_id = target_group + "-" + current
                con.execute(
                    "INSERT INTO attrs(id,data,attrs_type,binding_sheet_id,name,owner_id,sheet_type,is_hidden,created_at,updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(id) DO UPDATE SET data=excluded.data,attrs_type=excluded.attrs_type,"
                    "binding_sheet_id=excluded.binding_sheet_id,name=excluded.name,owner_id=excluded.owner_id,"
                    "sheet_type=excluded.sheet_type,is_hidden=excluded.is_hidden,updated_at=excluded.updated_at",
                    (target_id, bytes(a["data"] or b""), a["attrs_type"], a["binding_sheet_id"], a["name"],
                     current, a["sheet_type"], a["is_hidden"], a["created_at"] or now, now),
                )
                copied_attrs = 1

            if gp:
                g = dict(gp)
                existing = con.execute(
                    "SELECT id FROM group_player_info WHERE user_id=? AND group_id=? ORDER BY id LIMIT 1",
                    (current, target_group),
                ).fetchone()
                if existing:
                    con.execute(
                        "UPDATE group_player_info SET name=?,last_command_time=?,auto_set_name_template=?,dice_side_num=?,updated_at=? WHERE id=?",
                        (g["name"], g["last_command_time"] or 0, g["auto_set_name_template"] or "",
                         g["dice_side_num"] or 100, now, existing["id"]),
                    )
                else:
                    con.execute(
                        "INSERT INTO group_player_info(name,user_id,last_command_time,auto_set_name_template,dice_side_num,created_at,updated_at,group_id) VALUES(?,?,?,?,?,?,?,?)",
                        (g["name"], current, g["last_command_time"] or 0, g["auto_set_name_template"] or "",
                         g["dice_side_num"] or 100, g["created_at"] or now, now, target_group),
                    )

            # Commit the main data first. Log migration is intentionally isolated
            # from this transaction: a malformed/corrupt data-logs.db must NOT
            # roll back character cards, group attributes, or player information.
            con.commit()

            log_result = {
                "log_count": 0,
                "log_item_count": 0,
                "log_skipped": 0,
                "log_error": None,
            }
            try:
                log_result = self.migrate_logs(old_group_id, target_group)
            except Exception as e:
                # Keep the successful main-data migration and report the exact
                # log-side failure to the caller.
                log_result["log_error"] = f"{type(e).__name__}: {e}"
                self.log_error(f"Log migration failed for {old_group_id} -> {target_group}: {log_result['log_error']}")

            return {
                "ok": True,
                "characters": [{"name": n} for n in copied_chars],
                "character_count": len(copied_chars),
                "skipped_empty_characters": skipped_empty,
                "group_attr_count": copied_attrs,
                "log_count": log_result.get("log_count", 0),
                "log_item_count": log_result.get("log_item_count", 0),
                "log_skipped": log_result.get("log_skipped", 0),
                "log_error": log_result.get("log_error"),
                "backup": backup_path,
                "logs_backup": logs_backup_path,
            }
        except Exception:
            if con is not None:
                try: con.rollback()
                except Exception: pass
            raise
        finally:
            if con is not None:
                con.close()


class Handler(BaseHTTPRequestHandler):
    bridge = None

    def send_json(self, obj, status=200):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        try:
            u = urlparse(self.path)
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                body = json.loads(raw.decode("utf-8"))
            except Exception:
                raise RuntimeError("invalid JSON body")
            if u.path == "/set-email-config":
                self.send_json(self.bridge.set_email_config(body))
            elif u.path == "/email-test":
                self.send_json(self.bridge.send_test_email())
            else:
                self.send_json({"ok": False, "error": "not found"}, 404)
        except Exception as e:
            import traceback
            print("[ERROR] HTTP POST request failed:")
            traceback.print_exc()
            self.send_json({"ok": False, "error": f"{type(e).__name__}: {e}"}, 500)

    def do_GET(self):
        try:
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if u.path == "/health":
                self.send_json({"ok": True, "version": VERSION, "port": self.server.server_port,
                                "data_dir": self.bridge.data_dir})
            elif u.path == "/set-port":
                port = int(q.get("port", [""])[0])
                current = self.server.server_port
                saved = self.bridge.save_port(port)
                self.send_json({"ok": True, "port": saved, "old_port": current, "port_file": self.bridge.port_file})
                if saved != current:
                    # Return the response first, then let the CMD restart the bridge
                    # with the newly saved port.
                    import threading
                    threading.Timer(0.15, self.server.shutdown).start()
            elif u.path == "/lookup":
                old = q.get("old", [""])[0].strip().replace("QQ:", "")
                if not old:
                    raise RuntimeError("missing old")
                self.send_json(self.bridge.lookup(old))
            elif u.path == "/request-code":
                old = q.get("old", [""])[0].strip().replace("QQ:", "")
                current = q.get("current", [""])[0].strip()
                target_group = q.get("group", [""])[0].strip()
                old_group = q.get("oldGroup", [""])[0].strip().replace("QQ-Group:", "")
                if not all((old, current, target_group, old_group)):
                    raise RuntimeError("missing verification parameter")
                self.send_json(self.bridge.request_code(old, old_group, current, target_group))
            elif u.path == "/verify-code":
                old = q.get("old", [""])[0].strip().replace("QQ:", "")
                current = q.get("current", [""])[0].strip()
                target_group = q.get("group", [""])[0].strip()
                old_group = q.get("oldGroup", [""])[0].strip().replace("QQ-Group:", "")
                code = q.get("code", [""])[0].strip()
                if not all((old, current, target_group, old_group, code)):
                    raise RuntimeError("missing verification parameter")
                self.send_json(self.bridge.verify_code_and_bind(old, old_group, current, target_group, code))
            else:
                self.send_json({"ok": False, "error": "not found"}, 404)
        except Exception as e:
            import traceback
            print("[ERROR] HTTP request failed:")
            traceback.print_exc()
            self.send_json({"ok": False, "error": f"{type(e).__name__}: {e}"}, 500)

    def log_message(self, fmt, *args):
        print("[HTTP] " + (fmt % args))


def main():
    ap = argparse.ArgumentParser(description="OpenQQ QQ Sync Bridge v2.0")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--data-dir", default="data/default")
    args = ap.parse_args()
    bridge = Bridge(args.data_dir)
    if args.port is None:
        args.port = bridge.read_saved_port()
    if not 1 <= args.port <= 65535:
        raise SystemExit("Invalid port")
    bridge.check()
    Handler.bridge = bridge
    print(f"OpenQQ QQ Sync Bridge v{VERSION}")
    print(f"Listening: 127.0.0.1:{args.port}")
    print(f"Data dir: {bridge.data_dir}")
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()

if __name__ == "__main__":
    main()
