OpenQQ QQ Sync Bridge v2.0 多海豹使用鉴权版

作者：summer_pinellia@DNT

简介：
OpenQQ 与旧 QQ 数据迁移同步桥，支持多 SeaDice 实例，每个海豹实例可使用独立 Bridge 端口。
本版支持：
1. 多 SeaDice 实例分别配置 Bridge 端口。
2. 在 SeaDice 插件配置页面填写发件邮箱、SMTP 授权码、SMTP 服务器和端口。
3. .旧QQ邮箱测试：向配置中的发件邮箱发送测试邮件。
4. .旧QQ绑定 <旧QQ> <旧群>：自动向 <旧QQ>@qq.com 发送 6 位验证码。
5. .旧QQ验证码 <验证码>：验证成功后才执行数据迁移。
6. 验证码 5 分钟有效，最多错误 5 次。
7. 旧QQ+旧群已绑定其他 OpenQQ 身份时拒绝再次绑定。

请将exe文件和txt和json文件等一起放在海豹同目录下，和data等平行。
将js放入海豹的js插件中并且重载。
目录结构：Sealdice/
├─ Sealdice.exe
├─ ...
│
·
├─ data/
│  └─ default/
│     ├─ data.db
│     └─ data-logs.db
│   OpenQQ-QQ-Sync-Bridge-v1.0.exe
│   bridge_port.txt
│
└─ ...

js默认使用bridge监听端口是38999，如果需要用第二份海豹，需要在海豹js插件配置中将对应端口改成其他数字（不能和海豹任一端口号重合），同时修改txt文件当中的端口数字号，再双击启动该海豹目录下的openqq.exe。
*不同的海豹使用该插件的时候需要在对应目录放置并且开启不同端口的exe！！！

使用方式：
双击启动openqq.exe，然后保持运行，不能关闭
在目标QQ 群执行：
 如  .旧QQ绑定 2522629086 1081354778，也就是格式是： .旧QQ绑定 <本账号QQ><本QQ群账号>，后bot会朝你使用账号的QQ号@qq.com发送验证码邮件，输入。旧QQ验证码+6位数字的验证码后可绑定。再次绑定该群号和QQ账号会失败，仅限单次数绑定。QQ号+群号可用于多群进行绑定查询log。
绑定完成后再执行：
   .st或者。pc或者。log，先前的log可通过log get+名字取出。

注意：
- 插件配置中的“SMTP授权码”不是邮箱登录密码。
- QQ邮箱通常使用 smtp.qq.com:465，并使用 SMTP 授权码。
- 测试邮件会发送到你填写的“发件邮箱”本身。
- bridge_port.txt 与 EXE 放在同步桥目录中；EXE 默认读取其中的端口。
- email_config.json 仅作为兼容/手工启动备用配置，本版正常使用时由 SeaDice 插件配置向 Bridge 临时下发邮箱配置。

不要在干净备份上直接测试 .st；干净备份里的角色仍属于旧 QQ，OpenQQ 官 bot 不会自动显示它。

TIPS：因为文件只读取海豹的data和datalog的db文件，所以有的角色卡可能会在转换以后出现丢失情况，比如出现空角色卡，或者log绑定失败，大部分是因为数据库出现了问题，可用原始备份的data和datalog的db文件进行替换再删除相应的后缀为wal和shm的文件，海豹再度启动会自动生成相应的wal和shm干净文件。data文件会在数据转换前进行备份，后缀是beforexxxx
如十分必要可以来找骰主尝试找回数据。把data和datalog整理读取后可以得到对应的角色卡文件，只要存在过。
这版插件是AI写的代码，不能保证不会出现其他的bug，除此以外，尚未验证过该插件同步的log数据是否能继续记录日志。