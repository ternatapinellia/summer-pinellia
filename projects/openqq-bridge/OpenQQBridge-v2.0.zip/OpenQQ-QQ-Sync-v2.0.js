// ==UserScript==
// @name         OpenQQ旧QQ完整数据迁移-多海豹使用
// @author       summer_pinellia@DNT
// @version      2.0
// @description  OpenQQ 与旧 QQ 数据迁移；多 SeaDice 实例；绑定旧QQ时通过 旧QQ@qq.com 邮箱验证码确认【请下载相应的openqq.exe和bridge-port.txt】
// @sealVersion  >=1.6.0
// ==/UserScript==
(() => {
  const EXT_NAME='openqq_qq_realtime_sync_v20';
  const KEY='bindings_v20';
  const PORT_KEY='bridge_port_last_v20';
  if(seal.ext.find(EXT_NAME)) return;
  const ext=seal.ext.new(EXT_NAME,'summer_pinellia@DNT','2.0');

  const getPort=()=>{
    try {
      if(seal.ext.getIntConfig) {
        const p=Number(seal.ext.getIntConfig(ext,'bridge_port'));
        if(Number.isInteger(p)&&p>=1&&p<=65535) return p;
      }
    } catch(_) {}
    return 38999;
  };
  const bridge=()=>`http://127.0.0.1:${getPort()}`;
  const lastPort=()=>{try{const n=Number(ext.storageGet(PORT_KEY)||0);return Number.isInteger(n)&&n>=1&&n<=65535?n:0}catch(_){return 0}};
  const saveLastPort=p=>{try{ext.storageSet(PORT_KEY,String(p))}catch(_) {}};
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));

  async function syncPortToBridge(){
    const p=getPort();
    const candidates=[p,lastPort(),38999].filter((v,i,a)=>v&&a.indexOf(v)===i);
    for(const old of candidates){
      try{
        const r=await fetch(`http://127.0.0.1:${old}/set-port?port=${encodeURIComponent(p)}`);
        if(r.ok){saveLastPort(p); if(old!==p) await sleep(600); return true;}
      }catch(_){}
    }
    saveLastPort(p);
    return false;
  }

  const getB=()=>{try{return JSON.parse(ext.storageGet(KEY)||'{}')}catch(_){return {}}};
  const saveB=x=>ext.storageSet(KEY,JSON.stringify(x));
  const uid=c=>String(c?.player?.userId||'');
  const gid=c=>String(c?.group?.groupId||c?.group?.id||'');
  const reply=(ctx,msg,text)=>{try{seal.replyToSender(ctx,msg,String(text).slice(0,2000))}catch(_) {}};

  function cfgString(key, fallback=''){
    try { return String(seal.ext.getStringConfig(ext,key)||fallback).trim(); } catch(_) { return fallback; }
  }
  function smtpConfig(){
    return {
      sender_email: cfgString('sender_email',''),
      smtp_password: cfgString('smtp_password',''),
      smtp_host: cfgString('smtp_host','smtp.qq.com'),
      smtp_port: Number(seal.ext.getIntConfig(ext,'smtp_port')||465),
      smtp_ssl: true,
    };
  }

  async function postJson(path, body){
    let r;
    try {
      r=await fetch(bridge()+path,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(body||{})
      });
    } catch(e){ throw new Error(`无法连接同步桥 ${bridge()}：${e?.message||e}`); }
    const text=await r.text();
    let data={};
    try{data=JSON.parse(text||'{}')}catch(_){}
    if(!r.ok) throw new Error(data?.error||text||`bridge http ${r.status}`);
    if(data?.ok===false) throw new Error(data?.error||'同步桥返回失败');
    return data;
  }

  async function syncEmailConfig(){
    const c=smtpConfig();
    if(!c.sender_email) throw new Error('请先在插件配置中填写发件邮箱。');
    if(!c.smtp_password) throw new Error('请先在插件配置中填写SMTP授权码。');
    if(!/^\S+@\S+\.\S+$/.test(c.sender_email)) throw new Error('发件邮箱格式不正确。');
    if(!Number.isInteger(c.smtp_port)||c.smtp_port<1||c.smtp_port>65535) throw new Error('SMTP端口配置不正确。');
    await postJson('/set-email-config',c);
  }

  async function api(path,p){
    const q=Object.keys(p||{}).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(String(p[k]))).join('&');
    let r;
    try { r=await fetch(bridge()+path+(q?'?'+q:'')); }
    catch(e){ throw new Error(`无法连接同步桥 ${bridge()}：${e?.message||e}`); }
    const text=await r.text();
    let body={}; try { body=JSON.parse(text||'{}'); } catch(_) {}
    if(!r.ok) throw new Error(body?.error||text||`bridge http ${r.status}`);
    if(body?.ok===false) throw new Error(body?.error||'同步桥返回失败');
    return body;
  }

  function cmd(name,help,fn){
    const c=seal.ext.newCmdItemInfo(); c.name=name; c.help=help;
    c.solve=(ctx,msg,args)=>{
      fn(ctx,msg,args).catch(e=>{
        const reason=String(e?.message||e||'未知错误').replace(/^Error:\s*/,'').trim();
        reply(ctx,msg,`同步失败：${reason||'未知错误'}`);
      });
      return seal.ext.newCmdExecuteResult(true);
    };
    ext.cmdMap[name]=c;
  }

  const keyFor=c=>uid(c)+'|'+gid(c);
  const summary=r=>{
    const chars=Array.isArray(r?.characters)?r.characters:[];
    const names=chars.map(x=>typeof x==='string'?x:(x?.name||x?.title||x?.id||'')).filter(Boolean);
    let s=`同步完成！\n\n角色卡：${Number(r?.character_count??names.length)} 张`;
    if(names.length) s+='\n'+names.map(n=>`- ${n}`).join('\n');
    s+=`\n\n群属性：${Number(r?.group_attr_count||0)} 条`;
    if(r?.log_error){
      s+=`\nLog：迁移失败`;
      s+=`\nLog记录：未迁移`;
      s+=`\n原因：${String(r.log_error)}`;
    }else{
      s+=`\nLog：${Number(r?.log_count||0)} 个`;
      s+=`\nLog记录：${Number(r?.log_item_count||0)} 条`;
    }
    if(Array.isArray(r?.skipped_empty_characters)&&r.skipped_empty_characters.length)
      s+=`\n\n跳过空角色卡：${r.skipped_empty_characters.length} 张`;
    return s;
  };

  async function verifyBindCode(ctx,msg,code){
    await syncPortToBridge();
    await syncEmailConfig();
    const current=uid(ctx),group=gid(ctx);
    if(!current)return reply(ctx,msg,'无法读取用户ID。');
    if(!group)return reply(ctx,msg,'请在目标群执行。');
    const p=ext.storageGet('pending_bind_v20');
    let x=null; try{x=JSON.parse(p||'null')}catch(_){}
    if(!x || !x.oldQQ || !x.oldGroup) return reply(ctx,msg,'没有待验证的绑定请求，请先执行 .旧QQ绑定 <旧QQ> <旧群>。');
    if(x.current!==current || x.group!==group) return reply(ctx,msg,'当前账号或群与待验证请求不一致，请重新执行 .旧QQ绑定。');
    const r=await api('/verify-code',{old:x.oldQQ,current,group,oldGroup:x.oldGroup,code});
    const b=getB(),k=keyFor(ctx);
    b[k]={oldQQ:x.oldQQ,oldGroup:String(x.oldGroup),current,group,updatedAt:Date.now()}; saveB(b);
    ext.storageSet('pending_bind_v20','');
    reply(ctx,msg,summary(r));
  }

  async function bind(ctx,msg,old,oldGroup){
    await syncPortToBridge();
    const current=uid(ctx),group=gid(ctx);
    if(!current)return reply(ctx,msg,'无法读取用户ID。');
    if(!group)return reply(ctx,msg,'请在目标群执行。');
    const r=await api('/verify-code',{old,current,group,oldGroup,code:'__already_verified__'});
    reply(ctx,msg,summary(r));
  }

  cmd('旧QQ桥状态','检查同步桥',async(ctx,msg)=>{
    await syncPortToBridge();
    const r=await api('/health',{});
    reply(ctx,msg,r?.ok?`桥正常。\n端口：${r.port}\n版本：${r.version}`:'桥异常。');
  });

  cmd('旧QQ邮箱测试','测试发件邮箱：向配置中的发件邮箱发送测试邮件',async(ctx,msg)=>{
    await syncPortToBridge();
    await syncEmailConfig();
    const r=await postJson('/email-test',{});
    reply(ctx,msg,`测试邮件已发送至：${r.email}\n请检查收件箱（以及垃圾邮件）。`);
  });

  cmd('旧QQ绑定','申请旧QQ数据迁移验证码：.旧QQ绑定 <旧QQ> <旧群>',async(ctx,msg,args)=>{
    const old=args.getArgN(1).trim().replace(/^QQ:/i,'');
    const oldGroup=args.getArgN(2).trim().replace(/^QQ-Group:/i,'');
    if(!/^\d{5,20}$/.test(old)||!/^[0-9]{1,20}$/.test(oldGroup))return reply(ctx,msg,'格式错误。');
    const current=uid(ctx),group=gid(ctx);
    if(!current)return reply(ctx,msg,'无法读取用户ID。');
    if(!group)return reply(ctx,msg,'请在目标群执行。');
    await syncPortToBridge();
    await syncEmailConfig();
    const r=await api('/request-code',{old,current,group,oldGroup});
    ext.storageSet('pending_bind_v20',JSON.stringify({oldQQ:old,oldGroup:String(oldGroup),current,group,createdAt:Date.now()}));
    reply(ctx,msg,`验证邮件已发送至：${r.email}\n验证码有效期：5分钟。\n请在收到邮件后输入：.旧QQ验证码 <6位验证码>`);
  });

  cmd('旧QQ验证码','验证邮箱验证码并完成绑定：.旧QQ验证码 <6位验证码>',async(ctx,msg,args)=>{
    const code=args.getArgN(1).trim();
    if(!/^\d{6}$/.test(code))return reply(ctx,msg,'验证码应为6位数字。');
    await verifyBindCode(ctx,msg,code);
  });

  cmd('旧QQ同步','继续同步',async(ctx,msg)=>{
    const x=getB()[keyFor(ctx)];
    if(!x)return reply(ctx,msg,'请先绑定。');
    reply(ctx,msg,'当前版本绑定完成后会立即完成迁移，无需再次执行同步。');
  });

  cmd('旧QQ绑定信息','查看绑定',async(ctx,msg)=>{
    const x=getB()[keyFor(ctx)];
    reply(ctx,msg,x?`已绑定：QQ ${x.oldQQ} / 群 ${x.oldGroup}`:'未绑定。');
  });
  cmd('旧QQ角色','查看角色',async(ctx,msg,args)=>{
    let old=args.getArgN(1).trim().replace(/^QQ:/i,'');
    if(!old){const x=getB()[keyFor(ctx)];old=x?.oldQQ||'';}
    if(!/^\d{5,20}$/.test(old))return reply(ctx,msg,'请先绑定。');
    const r=await api('/lookup',{old});
    const chars=Array.isArray(r.characters)?r.characters:[];
    if(!chars.length)return reply(ctx,msg,'没有角色卡。');
    reply(ctx,msg,'角色卡：\n'+chars.map(x=>`- ${x.name||x.id}`).join('\n'));
  });
  cmd('旧QQ解绑','解除绑定',async(ctx,msg)=>{
    const b=getB(),k=keyFor(ctx);
    if(!b[k])return reply(ctx,msg,'未绑定。');
    delete b[k];saveB(b);reply(ctx,msg,'已解绑。');
  });

  seal.ext.register(ext);
  seal.ext.registerIntConfig(ext, 'bridge_port', 38999, 'Bridge端口', '同步桥设置');
  seal.ext.registerStringConfig(ext, 'sender_email', '', '发件邮箱', '邮箱验证设置');
  seal.ext.registerStringConfig(ext, 'smtp_password', '', 'SMTP授权码', '邮箱验证设置');
  seal.ext.registerStringConfig(ext, 'smtp_host', 'smtp.qq.com', 'SMTP服务器', '邮箱验证设置');
  seal.ext.registerIntConfig(ext, 'smtp_port', 465, 'SMTP端口', '邮箱验证设置');
})();
